"""
Class and methods to read, write, preview audiofiles.
"""
